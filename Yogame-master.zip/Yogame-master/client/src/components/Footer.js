

function Footer() {
    return (
			<div className="bg-primary-light p-1 w-full h-full flex justify-center text-jost text-sm font-semibold antialiased ">
				<a
					href="https://github.com/Anupam-Kumari/YogaInstructor"
					target="_blank"
					rel="noreferrer"
					className="flex"
				>
					<img
						src="https://img.icons8.com/material-outlined/18/000000/github.png"
						alt="Git"
					/>{" "}
					Github
				</a>
				, made by ❤ from
				<a
					href="https://github.com/AdityaPandey99"
					target="_blank"
					rel="noreferrer"
					className="flex ml-1"
				>
					Aditya Pandey
				</a>
				,
				<a
					href="https://github.com/Ananya2325/"
					target="_blank"
					rel="noreferrer"
					className="flex ml-1 mr-1"
				>
					Ananya Kumari Dayanand
				</a>
				,
				<a
					href="https://github.com/Anupam-Kumari"
					target="_blank"
					rel="noreferrer"
					className="flex ml-1"
				>
					Anupam Kumari
				</a>
				and
				<a
					href="https://github.com/YAKSHUMAKKAR39"
					target="_blank"
					rel="noreferrer"
					className="flex ml-1"
				>
					Yakshu Makkar
				</a>
			</div>
		);
}

export default Footer;
